export function convertToPercentage(num) {
  return (num * 100).toFixed(2);
}
